import 'package:flutter/material.dart';
import 'package:helloworld/services/world_time.dart';

class Loading extends StatefulWidget {
  Loading({Key? key}) : super(key: key);

  @override
  _LoadingState createState() => _LoadingState();
}

class _LoadingState extends State<Loading> {
  void getWorldTime() async {
    WorldTime instance =
        WorldTime(flag: 'berlin', location: 'london', url: 'Europe/london');

    await instance.getData();
    Navigator.pushReplacementNamed(this.context, '/home', arguments: {
      'location ': instance.location,
      'flag ': instance.flag,
      'time ': instance.time,
    });
  }

  @override
  void initState() {
    super.initState();
    getWorldTime();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text('loading'),
    );
  }
}
