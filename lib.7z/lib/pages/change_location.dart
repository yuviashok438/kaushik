import 'package:flutter/material.dart';

class ChangeLocation extends StatefulWidget {
  ChangeLocation({Key? key}) : super(key: key);

  @override
  _ChangeLocationState createState() => _ChangeLocationState();
}

class _ChangeLocationState extends State<ChangeLocation> {
  int counter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Change location '),
        centerTitle: true,
        backgroundColor: Colors.blue[500],
      ),
      body: RaisedButton(
        onPressed: () {
          setState(() {
            counter += 1;
          });
        },
        child: Text(' counter is $counter'),
      ),
    );
  }
}
